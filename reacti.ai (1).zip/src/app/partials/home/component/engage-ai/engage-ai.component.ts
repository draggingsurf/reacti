import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-engage-ai',
  templateUrl: './engage-ai.component.html',
  styleUrls: ['./engage-ai.component.scss']
})
export class EngageAiComponent implements OnInit{
ngOnInit(): void {
}
}
