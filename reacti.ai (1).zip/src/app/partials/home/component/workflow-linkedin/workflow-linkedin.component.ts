import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-workflow-linkedin',
  templateUrl: './workflow-linkedin.component.html',
  styleUrls: ['./workflow-linkedin.component.scss']
})
export class WorkflowLinkedinComponent implements OnInit{
  ngOnInit(): void{
  }
  constructor(){

  }
}
