import { Component, HostListener, ElementRef ,OnInit} from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
  
})
export class SliderComponent implements OnInit  {
  ngOnInit(): void {
  }
  
  constructor(private elementRef: ElementRef) { }

  
  @HostListener('window:scroll', ['$event'])
onWindowScroll() {
  const element = this.elementRef.nativeElement.querySelector('.step_boxs');
  const options = {
    threshold: 0.5
  };
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        // Add a class to the element to trigger a CSS animation
        element.classList.add('animate');
      } else {
        // Remove the class when the element is no longer in view
        element.classList.remove('animate');
      }
    });
  }, options);
  observer.observe(element);
}


}
