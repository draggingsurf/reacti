import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-human-like',
  templateUrl: './human-like.component.html',
  styleUrls: ['./human-like.component.scss']
})
export class HumanLikeComponent implements OnInit{
  ngOnInit(){
  }
  
}
