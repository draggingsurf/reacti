import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-comment-strategy',
  templateUrl: './comment-strategy.component.html',
  styleUrls: ['./comment-strategy.component.scss']
})
export class CommentStrategyComponent implements OnInit{
  ngOnInit(){

  }
}
