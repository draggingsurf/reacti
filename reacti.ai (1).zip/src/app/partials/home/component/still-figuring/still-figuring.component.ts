import { Component ,OnInit} from '@angular/core';

@Component({
  selector: 'app-still-figuring',
  templateUrl: './still-figuring.component.html',
  styleUrls: ['./still-figuring.component.scss']
})
export class StillFiguringComponent implements OnInit{
  ngOnInit(){
  }
}
