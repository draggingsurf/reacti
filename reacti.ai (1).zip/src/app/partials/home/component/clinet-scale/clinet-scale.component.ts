
import { Component, OnInit,HostListener ,ElementRef} from '@angular/core';
@Component({
  selector: 'app-clinet-scale',
  templateUrl: './clinet-scale.component.html',
  styleUrls: ['./clinet-scale.component.scss'],
})
export class ClinetScaleComponent implements OnInit {
  ngOnInit(): void{

  }
  
  
}
