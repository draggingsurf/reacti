import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './partials/header/header.component';
import { FooterComponent } from './partials/footer/footer.component';
import { HomeComponent } from './partials/home/home.component';

import { SliderComponent } from './partials/home/component/slider/slider.component';
import { EngageAiComponent } from './partials/home/component/engage-ai/engage-ai.component';
import { CommentStrategyComponent } from './partials/home/component/comment-strategy/comment-strategy.component';
import { WorkflowLinkedinComponent } from './partials/home/component/workflow-linkedin/workflow-linkedin.component';
import { CustomerReviewsComponent } from './partials/home/component/customer-reviews/customer-reviews.component';

import { ClinetScaleComponent } from './partials/home/component/clinet-scale/clinet-scale.component';
import { HumanLikeComponent } from './partials/home/component/human-like/human-like.component';
import { StillFiguringComponent } from './partials/home/component/still-figuring/still-figuring.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import AOS from 'aos';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    SliderComponent,
    EngageAiComponent,
    CommentStrategyComponent,
    WorkflowLinkedinComponent,
    CustomerReviewsComponent,
    ClinetScaleComponent,
    HumanLikeComponent,
    StillFiguringComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CarouselModule,
    BrowserAnimationsModule,
  
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor() {
    AOS.init({
      offset: 60,
      duration: 6000,
      easing: 'ease-in-out',
      delay: 0,
      once: false
    });
  }
}

